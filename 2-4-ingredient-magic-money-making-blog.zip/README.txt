# 2–4 Ingredient Magic — Money-Making Blog

## What is included
- `index.html` — the complete website design
- `recipes.js` — the recipe database; add recipes here without changing the website layout
- Search and category filters
- Kitchen-favorites affiliate area
- Affiliate disclosure
- Email-list signup placeholder
- Mobile-friendly layout

## How to add a recipe
Open `recipes.js`, copy one recipe object, paste it before the closing `];`, and change:
- title
- emoji
- category
- description
- ingredients
- steps
- tags

Save and upload the file. The site automatically displays the new recipe.

## How to put it online with GitHub Pages
1. Create/sign into a GitHub account.
2. Create a new repository.
3. For the easiest personal-site URL, name it `YOUR-GITHUB-USERNAME.github.io`.
4. Upload `index.html` and `recipes.js` to the root of the repository.
5. Open Settings → Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Choose the `main` branch and `/ (root)`.
8. Save.
9. Wait for GitHub Pages to publish. GitHub says publication can take up to about 10 minutes.
10. Your site will be at `https://YOUR-GITHUB-USERNAME.github.io`.

## Making money
1. Publish useful original recipes consistently.
2. Build an email list with a real email marketing provider.
3. Add affiliate links only after joining the affiliate programs and following their rules.
4. Later apply to an advertising network when the site has enough useful content and traffic to make ads worthwhile.
5. Create high-value articles such as:
   - "15 dinners with 4 ingredients"
   - "10 cheap meals for busy nights"
   - "Best kitchen tools for tiny kitchens"
   - "What to make when you have chicken + 2 ingredients"
6. Promote recipes on Pinterest, Facebook, Instagram, TikTok or other channels where your audience is active.
7. Keep a clear privacy policy and affiliate disclosure.

## Important
The buttons in the affiliate and email sections are intentionally placeholders. Replace them with real links/forms from services you actually use. Do not claim an affiliate relationship until you have joined the program.

## Custom domain
After the site works on GitHub Pages, you can buy a domain such as `24ingredientmagic.com` if available, then connect it through GitHub Pages' custom-domain settings and your domain registrar's DNS settings.
